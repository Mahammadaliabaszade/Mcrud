const multer = require('multer');
const path = require('path');
const express = require("express")
const { register, login, test, getAllUsers, getUserById} = require("../controller/auth")


const router = express.Router()

const storage = multer.diskStorage({
    destination: './public',
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
  });


  const upload = multer({
    storage: storage,
    limits: { fileSize: 100000000},
    fileFilter: function (req, file, cb) {
      checkFileType(file, cb);
    }
  }).single('photo');


  function checkFileType(file, cb) {
    const filetypes = /jpeg|jpg|png|gif|svg|webp/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
  
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb('Error!');
    }
  }
  router.route("/test").post(upload, test);

  router.route("/get-all-users").get(getAllUsers);
  router.route("/get-all-user/:id").get(getUserById);
router.route("/register").post(upload,register);
router.route("/login").post(login);



module.exports = router