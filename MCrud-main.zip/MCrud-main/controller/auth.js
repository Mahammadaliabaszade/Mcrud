const User = require("../models/auth");
const ErrorResponse = require("../middleware/error");


exports.register = async (req, res, next) => {
  console.log(process.env.API_URL, "dsadsads")
  const { email, firstName,lastName, password, avatar } = req.body;
  const { filename } = req.file;
  console.log(filename)
  try {
    const exsistUser = await User.findOne({ email });
    if (exsistUser) { 
        return  next();
    } else {
      const user = await User.create({
        firstName,
        lastName,
        email,
        password,
        avatar: `${process.env.API_URL}/${filename}`
      });
      sendToken(user, 201, res);
    }
  } catch (error) {
    next(error);
  }
};


exports.test = async (req, res, next) => {
  console.log("hello")
  const {filename}  = req.file;
try {
  console.log(filename)
} catch (error) {
    console.log(error, "hello")
}
};

exports.getUserById = async (req, res, next) => {
  try {
    const userId = req.params.id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'not found user' });
    }
    res.status(200).json({ user });
  } catch (error) {
    next(error);
  }
};

exports.getAllUsers = async (req, res, next) => {
  try {
    const users = await User.find();
    res.status(200).json({ users });
  } catch (error) {
    next(error);
  }
};

exports.login = async (req, res, next) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return  next();
  }
  try {
    const user = await User.findOne({ email }).select("+password");
    if (!user) {
        return  next();
    }

    const isMatch = await user.matchPassword(password);

    if (!isMatch || !user) {
      return  next();
    }
    else{
        sendToken(user, 200, res);
        console.log(user)
    }
  } catch (error) {
    next(error);
  }
};


const sendToken = async (user, statusCode, res) => {
    const token = user.getSingedToken()
    res.status(statusCode).json({success:true,token})
  };