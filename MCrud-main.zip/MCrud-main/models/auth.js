const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

mongoose.set("strictQuery", false);

const UserSchema = new mongoose.Schema(
    {
        firstName: {
            type: String,
            required: [true, "please provide a name"],
            maxLength: [26, "max length is 26 "],
            trim: true,
        },
        lastName: {
            type: String,
            required: [true, "please provide a name"],
            maxLength: [26, "max length is 26 "],
            trim: true,
        },
        email: {
            type: String,
            required: [true, "Please provide email address"],
            unique: true,
            lowercase: true,
            match: [
                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                "Please provide a valid email",
            ],
        },
        password: {
            type: String,
            required: [true, "Please add a password"],
            minlength: 6,
            select: false,
            // match: [
            //     /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%])(?=.*[0-9]).{8,}$/,
            //     "Please provide a valid password",
            // ],
        },
        avatar: {
            type: String,
        },
    },
    { timestamps: true }
);

UserSchema.pre("save", async function (next) {
    if (!this.isModified("password")) {
        next();
    }
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
});

UserSchema.methods.matchPassword = async function (password) {
    return await bcrypt.compare(password, this.password);
};

UserSchema.methods.getSingedToken = function () {
    return jwt.sign({ id: this._id, firstName: this.firstName, lastName: this.lastName, email: this.email, avatar: this.avatar, role: this.role }, process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE }
    );
};

const User = mongoose.model("User", UserSchema);

module.exports = User;